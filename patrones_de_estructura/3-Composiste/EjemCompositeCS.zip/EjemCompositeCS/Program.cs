﻿using System;

namespace EjemCompositeCS
{
    class Program
    {
        static void Main(string[] args)
        {
            Ingrediente oIngrediente1 = new Ingrediente("Harina", 100, 200, "gramos");
            Ingrediente oIngrediente2 = new Ingrediente("Leche", 20, 1, "litro");
            Ingrediente oIngrediente3 = new Ingrediente("Huevo", 20, 1, "kilo");
            PastelComposite oPastel = new PastelComposite("Pastel de leche");
            oPastel.Add(oIngrediente1);
            oPastel.Add(oIngrediente2);
            oPastel.Add(oIngrediente3);
            Console.WriteLine($"El costo del {oPastel.Nombre} es de {oPastel.CostoTotal}");
            Ingrediente oIngrediente4 = new Ingrediente("Chocolate", 200, 1, "litro");
            PastelComposite oPastelChocolareYLeche = new PastelComposite("Pastel compuestos de chocolate");
            oPastelChocolareYLeche.Add(oIngrediente4);
            oPastelChocolareYLeche.Add(oPastel);
            Console.WriteLine($"El costo del {oPastelChocolareYLeche.Nombre} es de {oPastelChocolareYLeche.CostoTotal}");
            Console.ReadKey();
        }
    }
}
